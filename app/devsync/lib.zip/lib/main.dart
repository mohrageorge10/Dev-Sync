import 'package:devsync/core/database/cache.dart';
import 'package:devsync/core/di/setup_locator.dart';
import 'package:devsync/core/routing/app_router.dart';
import 'package:devsync/core/theme/app_theme.dart';
import 'package:devsync/core/utils/devsync_enums.dart';
import 'package:devsync/features/ai_match/data/models/match_model.dart';
import 'package:devsync/features/ai_match/di/ai_match_di.dart';
import 'package:devsync/features/ai_match/screens/why_this_fits_screen.dart';
import 'package:devsync/firebase_options.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // await dotenv.load(fileName: '.env');

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  await CacheHelper.init();

  setupLocator();
  setupAiMatchDependencies();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.light,
      debugShowCheckedModeBanner: false,
      onGenerateRoute: AppRouter().generateRoute,
      home: WhyThisFitsScreen(
        match: MatchModel(
          projectId: 'p1',
          projectTitle: 'EcoTrack Mobile: Carbon Analytics',
          projectDescription: 'Track and reduce your carbon footprint.',
          purpose: ProjectPurpose.real,
          score: 92,
          matchedSkills: const ['Flutter', 'Dart', 'Firebase', 'REST APIs'],
          missingSkills: const ['Data Visualization', 'Unit Testing'],
          complementarySkills: const ['Git & GitHub', 'UI Design'],
          explanation:
              'Your Flutter and Firebase experience covers most of what this project needs.',
        ),
      ),
    );
  }
}