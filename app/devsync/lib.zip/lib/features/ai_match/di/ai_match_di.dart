import 'package:devsync/core/di/service_locator.dart';
import 'package:devsync/core/services/firebase/firebase_auth_service.dart';
import 'package:devsync/core/services/firebase/firestore_service.dart';
import 'package:devsync/features/ai_match/business_logic/match_actions_cubit.dart';
import 'package:devsync/features/ai_match/business_logic/match_cubit.dart';
import 'package:devsync/features/ai_match/business_logic/match_feedback_cubit.dart';
import 'package:devsync/features/ai_match/data/repos/match_repo.dart';

/// Registers the AI Match feature. Call it once, right after `setupLocator()`.
void setupAiMatchDependencies() {
  if (ServiceLocator.isRegistered<MatchRepo>()) return;

  ServiceLocator.registerLazySingleton<MatchRepo>(
    () => FirestoreMatchRepo(
      firestoreService: ServiceLocator.get<FirestoreService>(),
      authService: ServiceLocator.get<FirebaseAuthService>(),
    ),
  );

  // Factories: every screen / sheet gets its own Cubit.
  ServiceLocator.registerFactory<MatchCubit>(
    () => MatchCubit(ServiceLocator.get<MatchRepo>()),
  );
  ServiceLocator.registerFactory<MatchFeedbackCubit>(
    () => MatchFeedbackCubit(ServiceLocator.get<MatchRepo>()),
  );
  ServiceLocator.registerFactory<MatchActionsCubit>(
    () => MatchActionsCubit(ServiceLocator.get<MatchRepo>()),
  );
}
